let elForm=document.querySelector('.main_form');
let elUserInput=document.querySelector('.user_input');
let elWalker=document.querySelector('.walker');
let elBiker=document.querySelector('.biker');
let elDriver=document.querySelector('.driver');
let elPilot=document.querySelector('.pilot');
let elHiddenAlert=document.querySelector('.hidden_alert');
function validator() {
   let inputValue=Number(elUserInput.value.trim());
   // elUserInput.value=null;
   if(inputValue<=0 || isNaN(inputValue)) {
      elHiddenAlert.classList.add('early_return');
      return;
   }else {
      elHiddenAlert.classList.remove('early_return');
   }
   return inputValue;
}
function handleWalker() {
   let walkerSpeed=5/3.6;
   let walkerValue=(validator()*1000)/walkerSpeed;
   if(walkerValue<60) {
      return walkerValue+' s';
   } else if(walkerValue<3600) {
      return parseInt(walkerValue/60) + ' m ' +walkerValue%60 + ' s';
   } else {
      let minut=walkerValue-parseInt(walkerValue/3600)*3600
      return parseInt(walkerValue/3600) + ' s '+ parseInt(minut/60) + ' m '+walkerValue%60 + ' s';
   }
}
function handleBiker() {
   let bikerSpeed=20/3.6;
   let bikerValue=(validator()*1000)/bikerSpeed;
   if(bikerValue<60) {
      return bikerValue+' s';
   } else if(bikerValue<3600) {
      return parseInt(bikerValue/60) + ' m ' +bikerValue%60 + ' s';
   } else {
      let minut=bikerValue-parseInt(bikerValue/3600)*3600
      return parseInt(bikerValue/3600) + ' s '+ parseInt(minut/60) + ' m '+bikerValue%60 + ' s';
   }
}
function handleDriver() {
   let driverSpeed=80/3.6;
   let driverValue=(validator()*1000)/driverSpeed;
   if(driverValue<60) {
      return driverValue+' s';
   } else if(driverValue<3600) {
      return parseInt(driverValue/60) + ' m ' +driverValue%60 + ' s';
   } else {
      let minut=driverValue-parseInt(driverValue/3600)*3600
      return parseInt(driverValue/3600) + ' s '+ parseInt(minut/60) + ' m '+driverValue%60 + ' s';
   }
}
function handlePilot() {
   let pilotSpeed=800/3.6;
   let pilotValue=(validator()*1000)/pilotSpeed;
   if(pilotValue<60) {
      return pilotValue+' s';
   } else if(pilotValue<3600) {
      return parseInt(pilotValue/60) + ' m ' +pilotValue%60 + ' s';
   } else {
      let minut=pilotValue-parseInt(pilotValue/3600)*3600
      return parseInt(pilotValue/3600) + ' s '+ parseInt(minut/60) + ' m '+pilotValue%60 + ' s';
   }
}
function handleFormSubmit(evt) {
   evt.preventDefault();
   elWalker.textContent=handleWalker();
   elBiker.textContent=handleBiker();
   elDriver.textContent=handleDriver();
   elPilot.textContent=handlePilot();
}
elForm.addEventListener('submit', handleFormSubmit);